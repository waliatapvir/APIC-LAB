# -*- coding: utf-8 -*-
# Copyright 2020 Red Hat
# GNU General Public License v3.0+
# (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function


__metaclass__ = type

import ast
import re

from collections.abc import MutableMapping, MutableSequence

from ansible.errors import AnsibleActionFail
from ansible.module_utils.common.text.converters import to_native
from ansible.plugins.action import ActionBase
from jinja2 import Template, TemplateSyntaxError

from ansible_collections.ansible.utils.plugins.module_utils.common.argspec_validate import (
    AnsibleArgSpecValidator,
)
from ansible_collections.ansible.utils.plugins.modules.update_fact import DOCUMENTATION


class ActionModule(ActionBase):
    """action module"""

    _requires_connection = False

    def __init__(self, *args, **kwargs):
        """Start here"""
        super(ActionModule, self).__init__(*args, **kwargs)
        self._supports_async = True
        self._updates = None
        self._result = None

    def _check_argspec(self):
        aav = AnsibleArgSpecValidator(
            data=self._task.args,
            schema=DOCUMENTATION,
            name=self._task.action,
        )
        valid, errors, self._task.args = aav.validate()
        if not valid:
            raise AnsibleActionFail(errors)

    def _ensure_valid_jinja(self):
        """Ensure each path is jinja valid"""
        errors = []
        for entry in self._task.args["updates"]:
            try:
                Template("{{" + entry["path"] + "}}")
            except TemplateSyntaxError as exc:
                error = (
                    "While processing '{path}' found malformed path."
                    " Ensure syntax follows valid jinja format. The error was:"
                    " {error}"
                ).format(path=entry["path"], error=to_native(exc))
                errors.append(error)
        if errors:
            raise AnsibleActionFail(" ".join(errors))

    @staticmethod
    def _field_split(path):
        """Split the path into it's parts

        :param path: The user provided path
        :type path: str
        :return: the individual parts of the path
        :rtype: list
        """
        que = path
        fields = []
        # regex match dotted values and square brackets
        regex = re.compile(r"^[^\[\].]+|^\[[\'\"].+?[\'\"]\]|^\[.+?\]")
        while regex.match(que):
            m = regex.match(que)
            # remove outer square brackets
            field = re.sub(r"(^\[)|(\]$)", "", que[m.start() : m.end()])
            try:
                # make numbers numbers
                fields.append(ast.literal_eval(field))
            except Exception:
                # or strip the quotes
                fields.append(re.sub("['\"]", "", field))
            try:
                if que[m.end()] == ".":
                    que = que[m.end() + 1 :]
                else:
                    que = que[m.end() :]
            except IndexError:
                que = ""
        return fields

    def set_value(self, obj, path, val):
        """Set a value

        :param obj: The object to modify
        :type obj: mutable object
        :param path: The path to where the update should be made
        :type path: list
        :param val: The new value to place at path
        :type val: string, dict, list, bool, etc
        """
        first, rest = path[0], path[1:]
        if rest:
            try:
                new_obj = obj[first]
            except (KeyError, TypeError):
                msg = "Error: the key '{first}' was not found " "in {obj}.".format(
                    obj=obj,
                    first=first,
                )
                raise AnsibleActionFail(msg)
            self.set_value(new_obj, rest, val)
        else:
            if isinstance(obj, MutableMapping):
                if obj.get(first) != val:
                    self._result["changed"] = True
                    obj[first] = val
            elif isinstance(obj, MutableSequence):
                if not isinstance(first, int):
                    msg = (
                        "Error: {obj} is a list, "
                        "but index provided was not an integer: '{first}'"
                    ).format(obj=obj, first=first)
                    raise AnsibleActionFail(msg)
                if first > len(obj):
                    msg = "Error: {obj} not long enough for item #{first} to be set.".format(
                        obj=obj,
                        first=first,
                    )
                    raise AnsibleActionFail(msg)
                if first == len(obj):
                    obj.append(val)
                    self._result["changed"] = True
                else:
                    if obj[first] != val:
                        obj[first] = val
                        self._result["changed"] = True
            else:
                msg = "update_fact can only modify mutable objects."
                raise AnsibleActionFail(msg)

    def run(self, tmp=None, task_vars=None):
        """action entry point"""
        self._task.diff = False
        self._result = super(ActionModule, self).run(tmp, task_vars)
        self._result["changed"] = False
        self._check_argspec()
        results = set()
        full_replaces = set()  # keys that were fully replaced (no path)
        self._ensure_valid_jinja()
        # Use task_vars (top-level) instead of task_vars["vars"] to avoid the
        # deprecated internal "vars" dictionary (ansible-core 2.24, issue #426).
        for entry in self._task.args["updates"]:
            parts = self._field_split(entry["path"])
            obj, path = parts[0], parts[1:]
            results.add(obj)
            if obj not in task_vars:
                msg = "'{obj}' was not found in the current facts.".format(obj=obj)
                raise AnsibleActionFail(msg)
            retrieved = task_vars.get(obj)
            if path:
                self.set_value(retrieved, path, entry["value"])
            else:
                if retrieved != entry["value"]:
                    self._result.setdefault("ansible_facts", {})[obj] = entry["value"]
                    full_replaces.add(obj)
                    self._result["changed"] = True

        for key in results:
            if key in full_replaces:
                value = self._result.get("ansible_facts", {}).get(key)
            else:
                value = task_vars.get(key)
            self._result[key] = value
        return self._result
