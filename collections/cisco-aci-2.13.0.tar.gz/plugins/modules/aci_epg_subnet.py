#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Gaspard MICOL (@gmicol) <gmicol@cisco.com>

# GNU General Public License v3.0+ (see LICENSE or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function

__metaclass__ = type

ANSIBLE_METADATA = {"metadata_version": "1.1", "status": ["preview"], "supported_by": "certified"}

DOCUMENTATION = r"""
---
module: aci_epg_subnet
short_description: Manage EPG Subnets (fv:Subnet)
description:
- Manage EPG Subnets on Cisco ACI fabrics.
options:
  tenant:
    description:
    - The name of the Tenant.
    type: str
    aliases: [ tenant_name ]
  ap:
    description:
    - Name of an existing application network profile, that will contain the EPGs.
    type: str
    aliases: [ app_profile, app_profile_name ]
  epg:
    description:
    - Name of the end point group.
    type: str
    aliases: [ epg_name ]
  description:
    description:
    - The description for the Subnet.
    type: str
    aliases: [ descr ]
  enable_vip:
    description:
    - Determines if the Subnet should be treated as a VIP (virtual IP address).
    - The APIC defaults to C(false) when unset during creation.
    type: bool
  gateway:
    description:
    - The IPv4 or IPv6 gateway address for the Subnet.
    type: str
    aliases: [ gateway_ip ]
  mask:
    description:
    - The subnet mask for the Subnet.
    - This is the number associated with CIDR notation.
    - For IPv4 addresses, accepted values range between C(0) and C(32).
    - For IPv6 addresses, accepted Values range between C(0) and C(128).
    type: int
    aliases: [ subnet_mask ]
  nd_prefix_policy:
    description:
    - The IPv6 Neighbor Discovery Prefix Policy to associate with the Subnet.
    type: str
  preferred:
    description:
    - Determines if the Subnet is preferred over all available Subnets. Only one Subnet per Address Family (IPv4/IPv6) can be preferred in the Bridge Domain.
    - The APIC defaults to C(false) when unset during creation.
    type: bool
  route_profile:
    description:
    - The Route Profile to the associate with the Subnet.
    type: str
  route_profile_l3out:
    description:
    - The L3Out that contains the associated Route Profile.
    type: str
  scope:
    description:
    - Determines the scope of the Subnet.
    - The C(private) option only allows communication with hosts in the same VRF.
    - The C(public) option allows the Subnet to be advertised outside of the ACI Fabric, and allows communication with hosts in other VRFs.
    - The shared option limits communication to hosts in either the same VRF or the shared VRF.
    - The value is a list of options, C(private) and C(public) are mutually exclusive, but both can be used with C(shared).
    - The APIC defaults to C(private) when unset during creation.
    type: list
    elements: str
    choices: [ private, public, shared ]
  subnet_control:
    description:
    - Determines the Subnet's Control State.
    - The C(querier_ip) option is used to treat the gateway_ip as an IGMP querier source IP.
    - The C(nd_ra) option is used to treat the gateway_ip address as a Neighbor Discovery Router Advertisement Prefix.
    - The C(no_gw) option is used to remove default gateway functionality from the gateway address.
    - The APIC defaults to C(nd_ra) when unset during creation.
    type: str
    choices: [ nd_ra_prefix, no_default_gateway, querier_ip, unspecified ]
  subnet_name:
    description:
    - The name of the Subnet.
    type: str
    aliases: [ name ]
  ip_data_plane_learning:
    description:
    - Whether IP data plane learning is enabled or disabled.
    - The APIC defaults to C(enabled) when unset during creation.
    type: str
    choices: [ enabled, disabled ]
    aliases: [ ip_dataplane_learning ]
  state:
    description:
    - Use C(present) or C(absent) for adding or removing.
    - Use C(query) for listing an object or multiple objects.
    type: str
    choices: [ absent, present, query ]
    default: present
  name_alias:
    description:
    - The alias for the current object. This relates to the nameAlias field in ACI.
    type: str
extends_documentation_fragment:
- cisco.aci.aci
- cisco.aci.annotation

notes:
- The C(gateway) parameter is the root key used to access the Subnet (not name), so the C(gateway)
  is required when the state is C(absent) or C(present).
- The C(tenant), C(ap) and C(epg) used must exist before using this module in your playbook.
  The M(cisco.aci.aci_tenant) module, M(cisco.aci.aci_ap) and M(cisco.aci.aci_epg) can be used for these.
seealso:
- module: cisco.aci.aci_epg
- module: cisco.aci.aci_ap
- module: cisco.aci.aci_tenant
- name: APIC Management Information Model reference
  description: More information about the internal APIC class B(fv:Subnet).
  link: https://developer.cisco.com/docs/apic-mim-ref/
author:
- Gaspard MICOL (@gmicol)
"""

EXAMPLES = r"""
- name: Create a subnet
  cisco.aci.aci_epg_subnet:
    host: apic
    username: admin
    password: SomeSecretPassword
    tenant: production
    ap: intranet
    epg: web_epg
    gateway: 10.1.1.1
    mask: 24
    state: present
  delegate_to: localhost

- name: Create a subnet with options
  cisco.aci.aci_epg_subnet:
    host: apic
    username: admin
    password: SomeSecretPassword
    tenant: production
    ap: intranet
    epg: web_epg
    subnet_name: sql
    gateway: 10.1.2.1
    mask: 23
    description: SQL Servers
    scope: public
    route_profile_l3out: corp
    route_profile: corp_route_profile
    state: present
  delegate_to: localhost

- name: Update a subnets scope to private and shared
  cisco.aci.aci_epg_subnet:
    host: apic
    username: admin
    password: SomeSecretPassword
    tenant: production
    ap: intranet
    epg: web_epg
    gateway: 10.1.1.1
    mask: 24
    scope: [private, shared]
    state: present
  delegate_to: localhost

- name: Get all subnets
  cisco.aci.aci_epg_subnet:
    host: apic
    username: admin
    password: SomeSecretPassword
    state: query
  delegate_to: localhost

- name: Get all subnets of specific gateway in specified tenant
  cisco.aci.aci_epg_subnet:
    host: apic
    username: admin
    password: SomeSecretPassword
    tenant: production
    gateway: 10.1.1.1
    mask: 24
    state: query
  delegate_to: localhost
  register: query_result

- name: Get specific subnet
  cisco.aci.aci_epg_subnet:
    host: apic
    username: admin
    password: SomeSecretPassword
    tenant: production
    ap: intranet
    epg: web_epg
    gateway: 10.1.1.1
    mask: 24
    state: query
  delegate_to: localhost
  register: query_result

- name: Delete a subnet
  cisco.aci.aci_epg_subnet:
    host: apic
    username: admin
    password: SomeSecretPassword
    tenant: production
    ap: intranet
    epg: web_epg
    gateway: 10.1.1.1
    mask: 24
    state: absent
  delegate_to: localhost
"""

RETURN = r"""
current:
  description: The existing configuration from the APIC after the module has finished
  returned: success
  type: list
  sample:
    [
        {
            "fvTenant": {
                "attributes": {
                    "descr": "Production environment",
                    "dn": "uni/tn-production",
                    "name": "production",
                    "nameAlias": "",
                    "ownerKey": "",
                    "ownerTag": ""
                }
            }
        }
    ]
error:
  description: The error information as returned from the APIC
  returned: failure
  type: dict
  sample:
    {
        "code": "122",
        "text": "unknown managed object class foo"
    }
raw:
  description: The raw output returned by the APIC REST API (xml or json)
  returned: parse error
  type: str
  sample: '<?xml version="1.0" encoding="UTF-8"?><imdata totalCount="1"><error code="122" text="unknown managed object class foo"/></imdata>'
sent:
  description: The actual/minimal configuration pushed to the APIC
  returned: info
  type: list
  sample:
    {
        "fvTenant": {
            "attributes": {
                "descr": "Production environment"
            }
        }
    }
previous:
  description: The original configuration from the APIC before the module has started
  returned: info
  type: list
  sample:
    [
        {
            "fvTenant": {
                "attributes": {
                    "descr": "Production",
                    "dn": "uni/tn-production",
                    "name": "production",
                    "nameAlias": "",
                    "ownerKey": "",
                    "ownerTag": ""
                }
            }
        }
    ]
proposed:
  description: The assembled configuration from the user-provided parameters
  returned: info
  type: dict
  sample:
    {
        "fvTenant": {
            "attributes": {
                "descr": "Production environment",
                "name": "production"
            }
        }
    }
filter_string:
  description: The filter string used for the request
  returned: failure or debug
  type: str
  sample: ?rsp-prop-include=config-only
method:
  description: The HTTP method used for the request to the APIC
  returned: failure or debug
  type: str
  sample: POST
response:
  description: The HTTP response from the APIC
  returned: failure or debug
  type: str
  sample: OK (30 bytes)
status:
  description: The HTTP status from the APIC
  returned: failure or debug
  type: int
  sample: 200
url:
  description: The HTTP url used for the request to the APIC
  returned: failure or debug
  type: str
  sample: https://10.11.12.13/api/mo/uni/tn-production.json
"""

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.aci.plugins.module_utils.constants import SUBNET_CONTROL_MAPPING
from ansible_collections.cisco.aci.plugins.module_utils.aci import ACIModule, aci_argument_spec, aci_annotation_spec


def main():
    argument_spec = aci_argument_spec()
    argument_spec.update(aci_annotation_spec())
    argument_spec.update(
        tenant=dict(type="str", aliases=["tenant_name"]),  # Not required for querying all objects
        epg=dict(type="str", aliases=["epg_name"]),  # Not required for querying all objects
        ap=dict(type="str", aliases=["app_profile", "app_profile_name"]),  # Not required for querying all objects
        description=dict(type="str", aliases=["descr"]),
        enable_vip=dict(type="bool"),
        gateway=dict(type="str", aliases=["gateway_ip"]),  # Not required for querying all objects
        mask=dict(type="int", aliases=["subnet_mask"]),  # Not required for querying all objects
        subnet_name=dict(type="str", aliases=["name"]),
        nd_prefix_policy=dict(type="str"),
        preferred=dict(type="bool"),
        route_profile=dict(type="str"),
        route_profile_l3out=dict(type="str"),
        scope=dict(type="list", elements="str", choices=["private", "public", "shared"]),
        subnet_control=dict(type="str", choices=list(SUBNET_CONTROL_MAPPING.keys())),
        state=dict(type="str", default="present", choices=["absent", "present", "query"]),
        ip_data_plane_learning=dict(type="str", choices=["enabled", "disabled"], aliases=["ip_dataplane_learning"]),
        name_alias=dict(type="str"),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
        required_together=[["gateway", "mask"], ["route_profile_l3out", "route_profile"]],
        required_if=[
            ["state", "present", ["epg", "ap", "gateway", "mask", "tenant"]],
            ["state", "absent", ["epg", "ap", "gateway", "mask", "tenant"]],
        ],
    )

    aci = ACIModule(module)

    description = module.params.get("description")
    enable_vip = aci.boolean(module.params.get("enable_vip"))
    epg = module.params.get("epg")
    ap = module.params.get("ap")
    tenant = module.params.get("tenant")
    gateway = module.params.get("gateway")
    mask = module.params.get("mask")
    if mask is not None and mask not in range(0, 129):
        # TODO: split checks between IPv4 and IPv6 Addresses
        module.fail_json(msg="Valid Subnet Masks are 0 to 32 for IPv4 Addresses and 0 to 128 for IPv6 addresses")
    if gateway is not None:
        gateway = "{0}/{1}".format(gateway, mask)
    subnet_name = module.params.get("subnet_name")
    nd_prefix_policy = module.params.get("nd_prefix_policy")
    preferred = aci.boolean(module.params.get("preferred"))
    route_profile = module.params.get("route_profile")
    route_profile_l3out = module.params.get("route_profile_l3out")
    scope = module.params.get("scope")
    ip_data_plane_learning = module.params.get("ip_data_plane_learning")

    if scope is not None:
        if "private" in scope and "public" in scope:
            module.fail_json(msg="Parameter 'scope' cannot be both 'private' and 'public', got: %s" % scope)
        else:
            scope = ",".join(sorted(scope))
    state = module.params.get("state")
    subnet_control = module.params.get("subnet_control")
    if subnet_control:
        subnet_control = SUBNET_CONTROL_MAPPING[subnet_control]
    name_alias = module.params.get("name_alias")

    aci.construct_url(
        root_class=dict(
            aci_class="fvTenant",
            aci_rn="tn-{0}".format(tenant),
            module_object=tenant,
            target_filter={"name": tenant},
        ),
        subclass_1=dict(
            aci_class="fvAp",
            aci_rn="ap-{0}".format(ap),
            module_object=ap,
            target_filter={"name": ap},
        ),
        subclass_2=dict(
            aci_class="fvAEPg",
            aci_rn="epg-{0}".format(epg),
            module_object=epg,
            target_filter={"name": epg},
        ),
        subclass_3=dict(
            aci_class="fvSubnet",
            aci_rn="subnet-[{0}]".format(gateway),
            module_object=gateway,
            target_filter={"ip": gateway},
        ),
        child_classes=["fvRsBDSubnetToProfile", "fvRsNdPfxPol"],
    )

    aci.get_existing()

    if state == "present":
        aci.payload(
            aci_class="fvSubnet",
            class_config=dict(
                ctrl=subnet_control,
                descr=description,
                ip=gateway,
                name=subnet_name,
                preferred=preferred,
                scope=scope,
                virtual=enable_vip,
                nameAlias=name_alias,
                ipDPLearning=ip_data_plane_learning,
            ),
            child_configs=[
                {"fvRsBDSubnetToProfile": {"attributes": {"tnL3extOutName": route_profile_l3out, "tnRtctrlProfileName": route_profile}}},
                {"fvRsNdPfxPol": {"attributes": {"tnNdPfxPolName": nd_prefix_policy}}},
            ],
        )

        aci.get_diff(aci_class="fvSubnet")

        aci.post_config()

    elif state == "absent":
        aci.delete_config()

    aci.exit_json()


if __name__ == "__main__":
    main()
